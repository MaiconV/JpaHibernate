package com.algaworks.curso.jpa2.criteria;

public class CarModelTemp {

	private String placa;
	private String descricao;

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

}
